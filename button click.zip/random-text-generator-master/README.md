# random-text-generator
Simple flutter-app to keep showing changed random text on a button click. Shows meaningful message when out of random texts and allows to reset the text generator. It is not truly random as a list is parsed to fetch next text on each button click. Certainly more can be done in the future.
